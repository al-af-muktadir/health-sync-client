import ForgotPasswordForm from "@/components/auth/Login/ForgotPasswordForm";
import React from "react";

const ForgotPasswordPage = () => {
  return (
    <div>
      <ForgotPasswordForm />
    </div>
  );
};

export default ForgotPasswordPage;
