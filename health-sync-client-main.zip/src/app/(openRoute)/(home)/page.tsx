// import { Button } from "@/components/ui/button";

import { Banner } from "@/components/Basics/Banner";

export default function Home() {
  return (
    <div>
      <Banner />
    </div>
  );
}
