import RegisterForm from "@/components/auth/Register/RegisterForm";
import React from "react";

const RegisterPage = () => {
  return (
    <div>
      <RegisterForm />
    </div>
  );
};

export default RegisterPage;
