import React from "react";

const ResetPasswordPage = () => {
  return <div></div>;
};

export default ResetPasswordPage;
